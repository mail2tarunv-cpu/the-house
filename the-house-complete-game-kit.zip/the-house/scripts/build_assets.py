from pathlib import Path
from PIL import Image, ImageEnhance, ImageFilter
import math, random, json, io
import cairosvg
R=Path(__file__).resolve().parents[1]
A=R/'assets'
S=Image.open(A/'reference'/'art-direction-contact-sheet.png').convert('RGB')
# Crops from a concept sheet: individual enlarged scene artwork. They are beautiful comps and not falsely marketed as separated transparent layers.
crops={
 'house/house-full':(18,37,677,466),
 'rooms/lounge/lounge-dressed':(706,44,1145,463),
 'rooms/maya/maya-dressed':(1157,44,1526,242),
 'rooms/leo/leo-dressed':(1157,276,1526,463),
}
for k,box in crops.items():
 im=S.crop(box)
 # keep original detailing, upscale on HiDPI without harsh halos
 im=im.resize((im.width*3,im.height*3),Image.Resampling.LANCZOS)
 (A/(k+'.png')).parent.mkdir(parents=True,exist_ok=True)
 im.save(A/(k+'.png'),optimize=True)
S.save(A/'reference'/'art-direction-contact-sheet.png',optimize=True)

ink='#302e31'; warm='#e7bcaa'; green='#618878'; cream='#f8efdF'
def svg(body,w=256,h=256):
 return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><defs><filter id="s"><feGaussianBlur stdDeviation="3"/></filter><pattern id="grain" patternUnits="userSpaceOnUse" width="13" height="13"><circle cx="3" cy="4" r=".7" fill="#8e6f63" opacity=".3"/><circle cx="11" cy="8" r=".7" fill="#8e6f63" opacity=".2"/></pattern></defs>{body}</svg>'''
def path(d,fill='none',stroke=ink,sw=3,more=''):
 return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" {more}/>'
def rect(x,y,w,h,fill,rx=0,stroke=ink,sw=3):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def ellipse(x,y,rx,ry,fill,stroke='none',sw=2):
 return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def circle(x,y,r,fill,stroke=ink,sw=2):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def text(x,y,t,size=12,fill=ink):return f'<text x="{x}" y="{y}" font-size="{size}" font-family="Arial,sans-serif" font-weight="800" fill="{fill}" text-anchor="middle">{t}</text>'
props={}
props['sofa']=ellipse(130,226,104,12,'#71685e',sw=0)+rect(26,91,203,97,'#62917e',24)+rect(34,66,186,98,'#789f8b',27)+rect(18,123,39,79,'#567968',16)+rect(198,123,40,79,'#567968',16)+path('M126 104 L126 186',stroke='#356253',sw=3)+rect(55,138,60,37,'#dfa98e',10)+rect(142,137,53,38,'#ebd7ad',11)+path('M44 188 v22 M215 188 v22',stroke='#4e554c',sw=12)
props['tv-cabinet']=rect(30,95,194,115,'#b58161',6)+rect(38,104,178,96,'#ddbd96',3)+rect(48,27,160,116,'#373e42',4)+rect(57,37,142,97,'#718c92',1,stroke='#222930',sw=3)+path('M57 129 L128 65 L199 129',fill='#9db9ad',stroke='none')+path('M57 113 L128 78 L199 113',fill='#6d8e7e',stroke='none')+rect(43,151,170,49,'#b58363',3)+path('M129 154 v46',sw=2)+circle(118,175,3,'#d9bb82',stroke='none')+circle(140,175,3,'#d9bb82',stroke='none')
props['coffee-table']=ellipse(134,214,105,13,'#73706a',sw=0)+rect(47,103,171,42,'#b17d5d',14)+path('M62 143 L52 214 M199 143 L207 214',stroke='#6f5a50',sw=12)+ellipse(132,108,82,12,'#d9ac83',sw=2)+rect(82,83,49,28,'#dfcab0',4)+rect(144,71,41,34,'#b0cbb7',3)+ellipse(165,82,16,8,'#6a997d')
props['floor-lamp']=path('M92 220H178',stroke='#77614e',sw=9)+path('M135 221 V69',stroke='#615c55',sw=6)+path('M136 75 L82 47',stroke='#615c55',sw=6)+ellipse(79,56,30,27,'#ffe0a8')+path('M50 55 Q79 8 110 55 Z',fill='#f4d6a7',stroke=ink)
props['plant-large']=ellipse(121,227,76,12,'#5e6454',sw=0)+path('M128 150 Q58 101 76 29 M129 151Q151 63 189 42 M128 152 Q100 67 116 14 M130 151 Q180 112 205 115',stroke='#3c6d54',sw=7)+''.join(ellipse(x,y,26,13,c,stroke='#385746') for x,y,c in [(66,59,'#688f66'),(99,41,'#8cad75'),(169,65,'#70956d'),(199,110,'#86a77d'),(119,26,'#a8bd81'),(82,112,'#98b782')])+path('M83 158 L178 158 L168 224 L95 224 Z',fill='#b97e66')+path('M86 174 H176',stroke='#d4a58a',sw=3)
props['rug']=ellipse(128,136,112,61,'#e6b9a4',stroke='#905f67',sw=5)+ellipse(128,136,93,44,'#f4dccc',stroke='#a17a73',sw=3)+ellipse(128,136,64,27,'#e8c0ad',stroke='#a17a73',sw=2)+path('M23 126h210M28 146h200',stroke='#b38676',sw=2)
props['bookcase']=rect(40,12,176,226,'#a36e57',6)+rect(50,22,156,206,'#e0b88d',2)+''.join(rect(51,42+i*57,154,10,'#956b55',1) for i in range(4))+''.join(rect(58+(j*17),23+i*57+((j+i)%3)*4,13,39-((j+i)%3)*4,['#68867f','#b9897a','#d2ac76','#718395','#b5a3a0','#5b726e'][j%6],1,sw=1) for i in range(3) for j in range(8))
props['book-stack']=ellipse(131,204,74,10,'#757061',sw=0)+''.join(rect(64+i*2,170-i*25,132-i*7,27,['#b77b7b','#799c90','#b7a47d','#787f9c'][i],3) for i in range(4))+''.join(path(f'M{65+i*2} {180-i*25}h{128-i*7}',stroke='#ece3c8',sw=2) for i in range(4))
props['bed-green']=rect(33,105,193,120,'#ae836c',8)+rect(42,117,175,87,'#e5dac4',9)+rect(55,128,149,69,'#689486',12)+rect(43,79,185,57,'#b98974',12)+rect(59,96,72,42,'#eee3d2',11)+rect(138,96,69,42,'#eee3d2',11)+path('M56 185Q123 197 203 186',stroke='#d3c1a6',sw=4)
props['bed-coral']=rect(32,104,192,121,'#af8774',8)+rect(42,115,175,89,'#ecd9ca',9)+rect(53,129,153,69,'#e9a39c',12)+rect(42,78,186,56,'#b98579',12)+rect(54,96,73,40,'#f4e4d4',11)+rect(138,96,73,40,'#f4e4d4',11)+path('M59 176 Q123 197 202 177',stroke='#f9c1b5',sw=4)
props['desk']=rect(37,104,185,21,'#ad8063',2)+rect(49,122,18,109,'#805e4f')+rect(191,122,18,109,'#805e4f')+rect(107,63,70,48,'#718991',4)+rect(115,70,54,31,'#dae1ca',2)+path('M141 111v13 M116 125h51',stroke='#605a58',sw=5)+rect(73,96,27,7,'#e4c9aa',2)
props['chair']=path('M61 91L68 202M185 91L182 202',stroke='#725f55',sw=11)+rect(51,100,148,26,'#789386',9)+rect(61,33,124,85,'#6d9789',15)+path('M66 126 L76 222 M185 126 L194 222',stroke='#735c4b',sw=9)
props['guitar']=path('M130 165 Q76 143 94 99 Q112 70 130 106 Q147 75 166 100 Q193 143 139 165 Z',fill='#bc8061')+circle(129,124,20,'#efe1c0')+circle(129,124,14,'#835c4b')+rect(121,15,17,99,'#b48d6e',4)+''.join(path(f'M{124+i*3} 19 V157',stroke='#eee2be',sw=1) for i in range(4))
props['vinyl-console']=rect(30,107,194,124,'#a47966',5)+rect(40,119,175,95,'#d1aa89',2)+path('M44 155h167M100 155v55M155 155v55',stroke='#916753',sw=5)+rect(45,68,174,43,'#c38b72',5)+ellipse(128,86,60,13,'#2c323c')+ellipse(128,86,36,8,'#596873')+circle(128,86,7,'#d0a28b')+path('M182 65v20l-40 13',stroke='#e4d6c3',sw=3)
props['gallery-wall']=rect(12,18,238,214,'#ebdbc3',3,stroke='#e0c29d',sw=1)+''.join(rect(x,y,w,h,col,1) for x,y,w,h,col in [(23,41,66,76,'#91aca6'),(112,31,50,65,'#c4a8a5'),(183,55,53,80,'#97a8b9'),(28,138,65,70,'#d1b797'),(106,122,64,89,'#c3aaa4'),(185,148,48,56,'#c8b7a2')])+''.join(path(f'M{x+4} {y+h-10} l{w//2} -{h//2} l{w//2-8} {h//2}',fill='#65857c',stroke='none') for x,y,w,h in [(23,41,66,76),(112,31,50,65),(183,55,53,80),(28,138,65,70),(106,122,64,89),(185,148,48,56)])
props['photo-single']=rect(52,22,150,207,'#f5e8d4',3)+rect(64,34,126,150,'#82a8a6',1)+circle(146,78,21,'#ffe4aa')+path('M65 175L114 97L146 133L189 94V185H65Z',fill='#688c7a')+text(128,209,'SUMMER 2026',12,'#78625c')
props['posters']=rect(27,32,91,174,'#bf9a92',2)+rect(139,12,92,193,'#b9aa9b',2)+rect(38,43,70,149,'#a2afb1',1,sw=1)+rect(151,25,67,170,'#dab88c',1,sw=1)+ellipse(74,89,26,26,'#e6cda0')+path('M40 156 L76 101 L107 154',fill='#668f8a')+ellipse(185,89,22,38,'#8c879e')+text(184,175,'NIGHT',14,'#665867')
props['letter-envelope']=path('M34 64H220V194H34Z',fill='#f0dcc1')+path('M35 65L127 140L220 65',stroke='#a67b6c',sw=4)+path('M36 192L113 123M220 192L141 124',stroke='#ad8570',sw=3)+circle(128,141,21,'#b96d70')+text(128,148,'♥',18,'#fff1e3')
props['lamp']=ellipse(128,220,63,10,'#6f6658',sw=0)+path('M130 222V90',stroke='#6e625c',sw=9)+path('M92 105L130 31L166 105Z',fill='#e9cda6')+ellipse(128,101,38,11,'#e1b990')
props['mirror']=rect(47,22,166,211,'#a77b6c',12)+rect(56,29,146,196,'#c7d2c6',9)+path('M62 161L190 46 M61 188L200 64',stroke='#e5efdd',sw=13)+path('M135 32V218',stroke='#a7b4a9',sw=2)
props['photo-frames']=rect(21,65,74,110,'#ac7f6b',2)+rect(26,69,64,102,'#d2a88c',2)+rect(105,24,122,117,'#a78575',2)+rect(110,29,111,106,'#7eaa9b',2)+rect(110,161,111,65,'#ac7f6b',2)+rect(116,167,100,55,'#d0b4a0',2)+circle(58,104,19,'#fff0be')+path('M28 157L49 121L71 143L89 112V169H28Z',fill='#74978b')+circle(173,61,21,'#ffdaa7')+path('M113 129L144 88L176 119L220 74V137H113Z',fill='#587f70')
props['letter-stack']=rect(50,82,163,125,'#f3e4cc',6)+path('M50 83L132 142L211 83',stroke='#aa867c',sw=4)+rect(37,64,167,126,'#f9e9d4',3)+path('M38 66L121 131L204 66',stroke='#ae8574',sw=4)+circle(122,132,17,'#bd7773')
props['record-disc']=circle(127,125,96,'#313339')+''.join(circle(127,125,r,'none',stroke='#61646b',sw=2) for r in (79,62,46))+circle(127,125,28,'#d8a89c')+circle(127,125,8,'#f9e9ce')
props['beanbag']=ellipse(132,210,93,19,'#6f605e',sw=0)+path('M40 186Q32 116 103 88Q159 69 201 117Q235 174 196 203Q100 232 40 186Z',fill='#e8ad97')+path('M65 183Q120 154 198 187',stroke='#be7e78',sw=5)
props['cat']=ellipse(120,184,80,32,'#d2a279')+circle(184,156,34,'#d5a47b')+path('M166 135L168 113L183 125L202 112L204 139',fill='#d5a47b')+path('M38 174Q2 162 29 116',stroke='#c59477',sw=14)+circle(175,157,3,ink,stroke='none')+circle(195,158,3,ink,stroke='none')
props['rug-round']=ellipse(128,134,113,83,'#d6b59e',stroke='#9a7d70',sw=4)+ellipse(128,134,87,65,'#e9d6bb',stroke='#b08b75',sw=4)+ellipse(128,134,46,35,'#b7c5ae',stroke='#8d9b80',sw=4)
props['camera']=rect(36,77,184,119,'#6e787a',10)+rect(57,58,74,27,'#747b7b',2)+circle(130,138,52,'#323c42')+circle(130,138,36,'#8ba6a6')+circle(130,138,23,'#4e6774')+circle(193,95,10,'#e0b69b')
props['notebook']=rect(46,38,167,189,'#c98e7e',5)+rect(68,44,144,181,'#f4e6cc',4)+path('M86 60V206',stroke='#b6a896',sw=2)+''.join(path(f'M102 {i}H195',stroke='#bcafa0',sw=2) for i in range(76,191,23))
props['teacup']=ellipse(129,200,70,13,'#b09b8c',sw=0)+path('M62 105H195L177 184H82Z',fill='#e9d9c5')+path('M195 116Q234 124 211 160Q203 170 183 155',stroke='#b99888',sw=9)+ellipse(129,106,68,11,'#ad8369')
for name,body in props.items():
 fp=A/'props'/f'{name}.svg'
 fp.write_text(svg(body))
# More detailed consistent vector blank shells (not crops of a flattened, already furnished image).
def room_base(theme):
 clr={'lounge':('#e4ddcb','#c6a78d','#93a696'), 'maya':('#f0e0cc','#b7a68f','#9cb3a1'), 'leo':('#efdbd4','#bba795','#a6b0b2')}[theme]
 wall,floor,trim=clr
 body='''<defs><pattern id="wood" width="105" height="105" patternUnits="userSpaceOnUse"><path d="M0 0H105 M0 105H105" stroke="#96755f" stroke-width="3" opacity=".25"/><path d="M38 0V105 M93 0V105" stroke="#a1846a" stroke-width="2" opacity=".17"/></pattern></defs>'''
 body+=path('M75 125L610 40L1118 150L1118 552L602 670L75 540Z',fill=wall,sw=7)
 body+=path('M75 540L605 635L1118 552L1024 680L605 735L75 631Z',fill=floor,sw=6)
 body+=path('M75 540L605 635L1118 552L1024 680L605 735L75 631Z',fill='url(#wood)',stroke='none')
 body+=path('M605 635V735 M75 540V631 M1118 552L1024 680',sw=6)
 body+=path('M75 125L610 40L605 635L75 540Z',fill='#f2ebdb',sw=6)
 body+=path('M605 635L610 40L1118 150L1118 552Z',fill=wall,sw=6)
 body+=path('M95 160L585 82 M620 82L1088 184',stroke='#fff8e8',sw=4)
 body+=path('M135 243L280 221L282 428L135 451Z',fill=trim,sw=4)
 body+=path('M150 254L270 237L270 424L150 438Z',fill='#d1e0d9',sw=3)
 body+=path('M211 250L210 432',sw=3)+path('M150 339L269 329',sw=3)
 body+=path('M639 179L820 218L820 411L637 374Z',fill=trim,sw=5)+path('M651 194L804 230L805 394L651 366Z',fill='#d6e3db',sw=2)
 body+=path('M728 210L727 383',sw=3)
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" width="1200" height="800">{body}</svg>'
for rm in ['lounge','maya','leo']:
 (A/'rooms'/rm/f'{rm}-empty.svg').write_text(room_base(rm))
# Original, clean modular house shell overview independent of posed scene artwork.
def house_empty():
 q='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" width="1600" height="900">'
 q+=path('M300 180L800 76L1298 185L1298 706L798 816L300 718Z',fill='#f6eadd',sw=7)
 q+=path('M298 478L795 574L1301 475',stroke='#554f48',sw=12)
 q+=path('M802 80V565',stroke='#675e57',sw=13)
 q+=path('M300 182L795 269L795 562L300 478Z',fill='#efe6d8',sw=6)
 q+=path('M803 266L1297 186L1297 480L803 569Z',fill='#ebd8ce',sw=6)
 q+=path('M300 475L795 566L1298 476L1298 706L798 816L300 718Z',fill='#e2d6c5',sw=6)
 q+=path('M300 719L798 816L1298 705L1298 739L798 854L300 753Z',fill='#c3a88a',sw=7)
 q+='</svg>'
 return q
(A/'house'/'house-empty.svg').write_text(house_empty())
# actual transparent characters, each with source svg files and a PNG sprite atlas.
characters={
 'you':{'skin':'#b98169','hair':'#2f3236','shirt':'#759e93','pants':'#4e5a62','shoe':'#454044','accent':'#e6d0ae','style':'short'},
 'maya':{'skin':'#b97659','hair':'#302828','shirt':'#d48d86','pants':'#5e7372','shoe':'#734b4a','accent':'#ead6ba','style':'long'},
 'leo':{'skin':'#d6a07b','hair':'#544039','shirt':'#b9a06e','pants':'#647488','shoe':'#4e4c51','accent':'#e9d8bb','style':'curly'},
 'jay':{'skin':'#8a604c','hair':'#2f2a2c','shirt':'#819ab4','pants':'#5c5b75','shoe':'#383c45','accent':'#e5ceac','style':'short'}
}
def person(c,frame=0,pose='idle',flip=False):
 head,skin=c['hair'],c['skin'];shirt,pants=c['shirt'],c['pants'];sw=2.7
 step=[-5,0,5,0,-4,4][frame%6] if pose=='walk' else 0
 bob=[0,-2,-1,0][frame%4] if pose=='idle' else [0,-3,-1,0,-2,0][frame%6]
 ang=[-8,0,7,0,-7,7][frame%6] if pose=='walk' else [0,0,1,0][frame%4]
 a=f'<g transform="translate(5 {bob})">'
 a+=ellipse(57,129,28,6,'#342d29',stroke='none')
 a+=path(f'M47 88L{43+step} 122L{56+step} 122L60 91',fill=pants,sw=sw)+path(f'M66 91L{68-step} 122L{82-step} 122L78 87',fill=pants,sw=sw)
 a+=ellipse(53+step,125,13,5,c['shoe'],stroke='none')+ellipse(76-step,125,13,5,c['shoe'],stroke='none')
 a+=path(f'M47 62 Q31 76 {35+ang} 92',stroke=skin,sw=10)+path(f'M80 63 Q96 73 {89-ang} 89',stroke=skin,sw=10)
 a+=path('M42 57Q60 48 80 57L85 91Q61 102 40 91Z',fill=shirt,sw=sw)
 a+=path('M54 88H72',stroke=c['accent'],sw=3)
 a+=rect(56,45,12,17,skin,5,sw=2)
 a+=ellipse(62,30,23,26,skin,ink,sw)
 if c['style']=='long':
  a+=path('M39 31Q33 -6 67 0Q89 0 86 38L87 69L76 63L76 22Q65 7 51 19L49 61L37 72Z',fill=head,sw=2)
 elif c['style']=='curly':
  a+=''.join(circle(x,y,10,head,ink,1.5) for x,y in [(45,15),(53,6),(64,5),(77,9),(84,19),(39,24)])
 else:
  a+=path('M39 32Q31 0 63 2Q83 0 87 27L77 20L66 16L47 26L41 40Z',fill=head,sw=2)
 a+=circle(55,32,2.1,ink,stroke='none')+circle(72,32,2.1,ink,stroke='none')
 a+=path('M58 42Q64 46 70 41',stroke='#a66b64',sw=2)
 a+='</g>'
 if flip:a=f'<g transform="translate(136 0) scale(-1 1)">{a}</g>'
 return svg(a,136,144)
for name,c in characters.items():
 folder=A/'characters'/name;folder.mkdir(parents=True,exist_ok=True)
 for pose,frames in [('idle',4),('walk',6)]:
  out=[]
  for f in range(frames):
   source=person(c,f,pose); (folder/f'{pose}_{f:02d}.svg').write_text(source)
   raw=cairosvg.svg2png(bytestring=source.encode(),output_width=204,output_height=216)
   im=Image.open(io.BytesIO(raw)).convert('RGBA')
   im.save(folder/f'{pose}_{f:02d}.png')
   out.append(im)
  atlas=Image.new('RGBA',(204*frames,216))
  for i,im in enumerate(out):atlas.paste(im,(i*204,0))
  atlas.save(folder/f'{pose}-sheet.png')
# game data manifest
manifest={'note':'Independent SVG props and SVG/PNG character animation frames are production-ready source artwork. Illustrated compositions are flattened concept art and must not be treated as separable layers.', 'scene_art':list(crops),'character_sheets':{n:['idle-sheet.png','walk-sheet.png'] for n in characters},'transparent_props':sorted(props),'empty_shells':['house/house-empty.svg','rooms/lounge/lounge-empty.svg','rooms/maya/maya-empty.svg','rooms/leo/leo-empty.svg']}
(A/'asset-manifest.json').write_text(json.dumps(manifest,indent=2))
print('created',len(props),'props',len(characters),'characters',sum(1 for p in A.rglob('*') if p.is_file()),'files')
