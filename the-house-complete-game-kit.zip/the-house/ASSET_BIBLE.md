# The House — asset bible / art handoff

**Target aesthetic:** Fine-line, editorial, warm, miniature cutaway house on an off-white 16:9 canvas. Personal rooms feel distinct; one shared lounge anchors the composition. Avoid glossy 3D shading, neon outlines, generic emojis on walls, and bloated interface chrome.

## Correct layering model

**A beautiful illustration is not the same as a game asset atlas.** This package intentionally supplies two complementary systems:

1. **Illustrated composites:** a finished house visual and three separate decorated close-ups, each created from a single coherent AI art-direction sheet. These are the default scenes in the prototype, and are **flattened pixels**.
2. **Actual independent production assets:** transparent SVG objects, transparent PNG/ SVG character animation frames, sprite atlases, and empty architectural shells. Turn on **Layer view** while inside a room to inspect composability. Those modular assets are stylistically related but do **not** perfectly match the painted composites yet.

To reach final shipped-game quality, we'd need a controlled redraw of a single geometry-locked scene. An automatically generated contact sheet cannot give pixel-perfect foreground masks or a hidden backside for each pictured object.

## File inventory

| Kind | Included | Notes |
|---|---:|---|
| Illustrated full house (3 rooms, white space) | 1 | `assets/house/house-full.png` |
| Empty structural house SVG | 1 | `assets/house/house-empty.svg` |
| Illustrated dedicated room close-ups | 3 | Maya, Leo, lounge |
| Empty editable room shells | 3 | Maya, Leo, lounge |
| Independent editable prop SVGs | 29 | Transparent, stroke-based |
| Original character identities | 4 | you, Maya, Leo, Jay |
| Idle poses | 4 per person | SVG+PNG source, one atlas each |
| Walk poses | 6 per person | SVG+PNG source, one atlas each |
| Character raster animation atlases | 8 | 4 idle + 4 walk |
| Playable browser prototype | Yes | vanilla JS, HTML, CSS |
| Illustrated prompt/reference contact sheet | Yes | Design reference, not production sprites |
| User-provided third-party artwork | **No** | Deliberately excluded from distributable ZIP |

## Room composition

### House overview

- 16:9 game frame, warm-white backdrop; centered house.
- Exactly three clickable spaces: Maya's room, Leo's room, shared lounge.
- Room-click targets: `hit-maya`, `hit-leo`, `hit-lounge` in CSS.
- Cursor changes, hover highlights, reveal labels. Clicking zooms (fade/swap) to a dedicated close-up rather than magnifying the low-resolution house crop.

### Maya's room — books and thoughtful notes

**Available interactive hotpots:** bookshelf, gallery, movie favorites, letter desk.

**Modular props in Layer view:** green bed, tall bookcase, desk, chair, leafy plant, lamp, books.

### Leo's room — films and music

**Available interactive hotspots:** movie wall, record player, gallery, letter desk.

**Modular props in Layer view:** coral bed, vinyl console, guitar, poster wall, beanbag, plants, record.

### Shared lounge — relationship-based storytelling

**Interactive hotspots:** memory wall, TV cabinet, letters, coffee table.

**Dynamic state:** You (baseline), You+Maya, You+Maya+Leo; switching people changes the visible memory card. The room currently does not run multiplayer networking. Private letters are never disclosed in the lounge.

**Modular props in Layer view:** sofa, TV cabinet, coffee table, large plant, rug, lamp, photo wall, letter stack.

## Illustration quality and depth rules

- Use identical camera perspective and wall angles in every overview/zoom scene.
- Export 2× or 3× over intended display size, and downsample when rendered. Don't enlarge a single crop indefinitely.
- Maintain furniture contact shadows underneath assets and separate foreground occlusion parts (sofa fronts, table fronts, chair legs) for real character overlap.
- Character feet belong to the floor plane. Sort render order by their feet's Y coordinate.
- Share one ink-outline weight family (about 2–3 source-vector units at 256px icons).
- Preserve negative space near interactive hotspots so they don't cover primary story moments.
- A decorative asset is **not** automatically interactive. Only objects with useful content receive a hotspot.

## Exact interactive object states

| Object | Default | On interaction | Persistence |
|---|---|---|---|
| Book wall | Curated reading shelf | Book details and why the owner cares | Static demo |
| Movie wall | Curated poster row | Owner's personal film story | Static demo |
| Photo gallery | Memory display | Opens caption and story | Static demo |
| Letter | Envelope on desk | Write, seal, reopen the local message | Browser only |
| TV cabinet | TV / movie display | Suggest adding a shared movie | Browser only |
| Lounge memory wall | Neutral group memory | Displays different group memories based on participants | Current session |
| Coffee table | Shared objects | Opens a shared story | Current session |
| Character | Animated idle loop | Moves over constrained floor strip on room click | Current session |

## Recommended final production exports (not in ZIP yet)

For every named interactive prop, production-ready transparent sprites should include: `idle/default`, `hover` or programmatic outline, `active/open`, **foreground-mask**, and an occlusion/pivot anchor. Not every asset needs 3–4 raster variants: CSS and filter states are fine for simple highlights.

For every character, a final directional sprite set should include **front/back/left/right** idle + walking, sit, reach, interact with book, type, hold a letter, inspect a poster, and sit on lounge couch. Current starter atlases use frontal orientation with mirrored movement and no character-furniture occlusion.

For final production cross-scene fidelity, the next art task is to replace the composites with a **single scene graph made of SVG/PSD source layers exported to transparent sprites**, rather than generating unrelated room images independently.

## Build and integration

- `index.html` — UI markup.
- `styles.css` — all screen styling, hover/focus, animation, responsive layout.
- `script.js` — room navigation, hotspots, letters, visitor simulation, panels, constrained walk behavior.
- `assets/asset-manifest.json` — object and character source manifest.
- `assets/scene-data.json` — scene and hotspots reference data.
- `scripts/build_assets.py` — regenerates illustrated crops and modular sprites using Pillow + CairoSVG.
- Deploy as a static site to Vercel; **Framework: Other**, **Output Directory: `./`**.

## What is not implemented yet

Actual friends or account login, realtime multiplayer, true letter delivery, third-party media imports, collision detection, pathfinding, depth-sorted occlusion, camera-parallax between layers, sophisticated four-directional walking, physics, public feeds, accessibility narration for the illustrated art itself, and long-term shared-room storage.

The interactions shown are intentionally a polished **concept game prototype**, not a commercially complete social app.
