# Install this ZIP into the existing GitHub project

Repository: https://github.com/mail2tarunv-cpu/the-house

## Easy path — GitHub Desktop on Mac

1. Download and extract `the-house-complete-game-kit.zip`. Inside it is a folder named `the-house` with `index.html`, `script.js`, `styles.css`, `vercel.json`, and `assets/`.
2. Open **GitHub Desktop → File → Clone Repository**, and clone `mail2tarunv-cpu/the-house` to your computer.
3. In GitHub Desktop, create a new branch named `feat/three-room-game` from `main` (Branch → New Branch).
4. Open the cloned repository folder in Finder. **Copy the contents of the extracted `the-house` folder** into the cloned repository's root, allowing replacement of existing files. Don't copy the outer folder so the result is nested at `the-house/the-house/`.
5. In GitHub Desktop, review the changed files, commit `Build layered three-room prototype`, then **Push origin**.
6. Open GitHub and create a Pull Request from `feat/three-room-game` to `main`.
7. Review the Vercel Preview URL first. Merge only when the preview is correct.

## Command line alternative

After extracting the ZIP, from Terminal:

```bash
git clone https://github.com/mail2tarunv-cpu/the-house.git
cd the-house
git checkout -b feat/three-room-game
cp -R ~/Downloads/the-house/. ./
git add .
git commit -m "Build layered three-room prototype"
git push -u origin feat/three-room-game
```

Adjust `~/Downloads/the-house` if macOS extracted the ZIP elsewhere. If a branch of the same name already exists, choose a new branch name.

## Vercel project settings

- Repository: `mail2tarunv-cpu/the-house`
- Framework Preset: **Other**
- Root Directory: `./` (repository root)
- Build Command: **blank/no override**
- Output Directory: `./`
- Production Branch: `main`

Vercel will typically create a preview deployment when the feature branch is pushed. Because the production branch stays `main`, the existing production deployment shouldn't be replaced until you merge or intentionally deploy to production.

## Local preview before committing

Inside the extracted `the-house` directory:

```bash
python3 -m http.server 3000
```

Open `http://localhost:3000` in your browser. Click the three rooms, test the floating object buttons, send a sample letter, and toggle visitors in the lounge.

## Scope / production reality

The ZIP contains working interaction code and original transparent starter sprites. It does **not** include production multiplayer, database-backed messages, collision-aware free roaming, or precisely matched individual prop cutouts from the rendered concept paintings. The full painted scenes are reference-quality flattened composites; use **Layer view** to inspect modular props and empty rooms.
