# The House — playable illustrated prototype

A three-room, story-rich, close-friends game concept. A centered cutaway house on a white background; personal rooms for Maya and Leo; a relationship-responsive lounge.

## Run

There are **no dependencies and no build step**. Open the project through a local HTTP server:

```bash
python3 -m http.server 3000
```

Open http://localhost:3000.

To deploy on Vercel: connect the GitHub repository, **Framework: Other**, root `./`, no build command, output directory `./`.

## Interaction walkthrough

1. Click one of the three rooms in the illustrated house.
2. The view transitions to a separate close-up room artwork.
3. Use the floating circular hotspots to explore books, movies, photo stories, a record player, and letters.
4. Write a letter for Maya or Leo. It's deliberately **local browser state only**, not a real message.
5. Open the shared lounge and toggle the Maya/Leo visitor chips. The memory object changes depending on who's present.
6. Try **Layer view** in a room. This demonstrates the empty architectural backdrop and separately positioned transparent SVG prop assets.
7. Press Esc or the back button to return to the house. Keyboard tab focus is supported for hotspots.

## What's included

- `assets/house/house-full.png` — fully illustrated centered hero house (flattened visual composite).
- `assets/house/house-empty.svg` — original empty structural architecture.
- `assets/rooms/{lounge,maya,leo}/*-dressed.png` — illustrated close-up composite references, separate per room.
- `assets/rooms/{lounge,maya,leo}/*-empty.svg` — editable architectural room shells with no furniture.
- `assets/props/*.svg` — 29 **independent transparent editable sprite/prop illustrations**. Used in Layer view.
- `assets/characters/{you,maya,leo,jay}/idle_*.{svg,png}` — each character has four independently rendered idle frames.
- `assets/characters/{you,maya,leo,jay}/walk_*.{svg,png}` — each character has six independently rendered walk frames.
- `assets/characters/*/*-sheet.png` — actual raster sprite atlases for game animation.
- `assets/reference/` — user-provided references and art-direction contact sheet, for design discussion only.
- `assets/asset-manifest.json` — machine-readable asset inventory.
- `scripts/build_assets.py` — regenerate scene crops and SVG/PNG assets. Requires Pillow and CairoSVG.
- `index.html`, `styles.css`, `script.js`, `vercel.json` — working, dependency-free web prototype.

## Important production limitations

The **illustrated room composites are raster paintings**. They are not magically separable into exact matching layers, and the independent SVG furniture is **a coherent stylized fallback** rather than pixel-perfect cutouts from those paintings. That distinction is deliberate and visible in the Layer view. You can replace both the composites and individual SVG assets with commissioned production art later.

The room scenes use clickable hotspots, not full 3D positional movement. Character idle/walk PNG spritesheets are included, but true 4-way directional character controls, proper collisions, multiuser presence, and content synchronization are **not implemented**. The live interaction focuses on click-to-enter, investigate personal objects, note-writing, and deterministic shared lounge changes.

The concept-image sheet contains labels and montages that are **not sprites**. It is marked as reference only. Some people depicted inside the flattened illustrated scenes cannot be separately animated until each character is redrawn as a production sprite.

## Visual parameters

- Full game viewport: 16:9, with 4:5 adaptation on mobile.
- House composition: centered on warm-white background.
- Rooms: bookish personal room, music/media personal room, shared lounge.
- Brand/UI: editorial serif headings, muted green navigation, terracotta highlights, intentionally minimal game chrome.
- Multiple image backdrops and individual sprite sources included for gradual production iteration.

## Credits

Original code and programmatically generated sprite artwork created for The House. The ZIP contains an AI-generated concept sheet but **does not redistribute the user-provided reference illustration**. Please do not upload third-party reference artwork as if it were original game art.
