(() => {
  'use strict';
  const base='./assets/';
  const scene=document.getElementById('scene-content');
  const shell=document.getElementById('game-scene');
  const breadcrumb=document.getElementById('breadcrumbs');
  const hint=document.getElementById('stage-hint');
  const back=document.getElementById('back-btn');
  const shade=document.getElementById('scene-shade');
  const sheet=document.getElementById('story-sheet');
  const scrim=document.getElementById('sheet-scrim');
  const body=document.getElementById('sheet-body');
  const category=document.getElementById('sheet-category');
  const status=document.getElementById('scene-status');
  const toast=document.getElementById('toast');
  const artToggle=document.getElementById('art-toggle');
  const soundToggle=document.getElementById('sound-toggle');
  let view='house',layered=false,sound=false,animateToken=0,toastTimer=null,previousFocus=null,walkTimer=null;
  const join=new Set(['you','maya']);
  const friends={
    maya:{name:'Maya',caption:'the quiet collector',desc:'Books, handwritten postcards, coffee on rainy days.',image:'rooms/maya/maya-dressed.png',character:'maya',theme:'#e8ddd0'},
    leo:{name:'Leo',caption:'the music person',desc:'Movie posters, late-night records, and songs with stories.',image:'rooms/leo/leo-dressed.png',character:'leo',theme:'#f4e4d8'},
    lounge:{name:'The living room',caption:'where everyone meets',desc:'A space that remembers the things you have in common.',image:'rooms/lounge/lounge-dressed.png',character:'you',theme:'#e9eadf'}
  };
  const entries={
    maya:{
      books:[{title:'Normal People',detail:'“I underlined half of it, then read it again.”',image:'book-stack.svg'},{title:'Crying in H Mart',detail:'“This reminded me of home.”',image:'bookcase.svg'}],
      movie:[{title:'Before Sunrise',detail:'“Two strangers just talking. It feels so real.”',image:'posters.svg'}],
      gallery:[{title:'The train that never came',detail:'“We missed the last train. It became our favorite night.”',image:'photo-single.svg'}]
    },
    leo:{
      books:[{title:'Kitchen Confidential',detail:'“You have to read the first chapter.”',image:'book-stack.svg'}],
      movie:[{title:'The Grand Budapest Hotel',detail:'“Everything about the colors and the timing.”',image:'posters.svg'},{title:'Interstellar',detail:'“I keep coming back for the soundtrack.”',image:'record-disc.svg'}],
      gallery:[{title:'Sunday at the record shop',detail:'“A $2 record and the best afternoon.”',image:'photo-single.svg'}]
    }
  };
  const hotspots={
    maya:[{id:'books',label:'Book wall',icon:'▤',x:70,y:40},{id:'gallery',label:'Photo gallery',icon:'▧',x:47,y:27},{id:'letter',label:'Leave a letter',icon:'✉',x:48,y:69},{id:'movie',label:'Movie favorites',icon:'▸',x:82,y:20}],
    leo:[{id:'movie',label:'Movie wall',icon:'▸',x:31,y:33},{id:'music',label:'Record player',icon:'♫',x:40,y:66},{id:'gallery',label:'Gallery',icon:'▧',x:70,y:35},{id:'letter',label:'Leave a letter',icon:'✉',x:76,y:71}],
    lounge:[{id:'memory',label:'Memory wall',icon:'▧',x:69,y:31},{id:'tv',label:'The TV cabinet',icon:'▸',x:60,y:51},{id:'letters',label:'Letters',icon:'✉',x:34,y:73},{id:'table',label:'Coffee table',icon:'☕',x:52,y:73}]
  };
  function escapeHTML(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function load(){try{const v=JSON.parse(localStorage.getItem('the-house-demo-v1')||'{}');return v&&typeof v==='object'?v:{}}catch{return {}}}
  const saved=load();saved.letters=saved.letters&&typeof saved.letters==='object'?saved.letters:{};saved.watch=saved.watch||[];
  function save(){try{localStorage.setItem('the-house-demo-v1',JSON.stringify(saved))}catch{}}
  function prop(name,style=''){return `<img src="${base}props/${name}.svg" alt="" draggable="false" class="prop-img" style="${style}"/>`;}
  function showToast(message){toast.textContent=message;toast.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.hidden=true,2900);}
  let audioCtx=null;
  function clickSound(){if(!sound)return;try{audioCtx??=new (window.AudioContext||window.webkitAudioContext)();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type='sine';osc.frequency.setValueAtTime(550,audioCtx.currentTime);osc.frequency.exponentialRampToValueAtTime(725,audioCtx.currentTime+.11);gain.gain.setValueAtTime(.017,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+.14);osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+.14);}catch{}}
  function showSheet(type,content){previousFocus=document.activeElement;category.textContent=type;body.innerHTML=content;sheet.hidden=false;scrim.hidden=false;document.getElementById('close-sheet').focus();}
  function closeSheet(){sheet.hidden=true;scrim.hidden=true;body.innerHTML='';previousFocus?.focus?.();}
  function transition(next){clickSound();shade.classList.add('transitioning');setTimeout(()=>{view=next;draw();requestAnimationFrame(()=>shade.classList.remove('transitioning'))},210);}
  function enter(id){if(!friends[id])return;transition(id);}
  function goHome(){transition('house');}
  function draw(){closeSheet();shell.className='game-scene '+(view==='house'?'scene-house':'scene-room');back.hidden=view==='house';artToggle.disabled=view==='house';const label=view==='house'?'the house':friends[view].name.toLowerCase();breadcrumb.innerHTML=`<span>OUR PLACE</span><b> / </b><strong>${escapeHTML(label)}</strong>`;
    status.textContent=view==='house'?'Click any room to begin':view==='lounge'?'Choose who joins the lounge':`Click objects to discover ${friends[view].name}'s story`;
    hint.textContent=view==='house'?'✳ Choose a room to step inside':view==='lounge'?'✳ Invite someone. Watch the room remember.':'✳ Tap an object to see what it holds';
    if(view==='house')drawHouse();else drawRoom(view);
  }
  function drawHouse(){scene.innerHTML=`<div class="house-scene"><div class="decorative-title"><h1>A place<br>for your<br>people.</h1><p>Your favorite things. Their little stories. A home you share.</p></div><div class="house-illustration"><img src="${base}house/house-full.png" alt="Cutaway illustrated house with two personal rooms upstairs and a shared living room downstairs"><button class="room-hit hit-maya" data-room="maya" aria-label="Enter Maya's reading room"><span>Maya's room ↗</span></button><button class="room-hit hit-leo" data-room="leo" aria-label="Enter Leo's creative room"><span>Leo's room ↗</span></button><button class="room-hit hit-lounge" data-room="lounge" aria-label="Enter the shared lounge"><span>The shared lounge ↗</span></button></div><span class="editorial-stamp">Made for your closest people · 2026</span></div>`;}
  function layerProps(id){
    const sets={
      maya:[['bed-green',26,54,25],['bookcase',53,22,22],['desk',68,64,17],['plant-large',38,38,14],['chair',54,65,13],['book-stack',72,37,9],['lamp',25,26,13]],
      leo:[['bed-coral',54,50,26],['vinyl-console',28,49,17],['guitar',56,39,12],['posters',64,30,14],['plant-large',29,37,13],['beanbag',45,72,14],['record-disc',75,62,8]],
      lounge:[['sofa',31,59,29],['tv-cabinet',66,43,21],['coffee-table',52,72,19],['plant-large',20,45,11],['floor-lamp',81,40,12],['rug-round',48,79,28],['gallery-wall',73,25,17],['letter-stack',27,72,9]]};
    return `<div class="layered-props">${sets[id].map(([name,x,y,w])=>prop(name,`left:${x}%;top:${y}%;width:${w}%;transform:translate(-50%,-50%)`)).join('')}</div>`;
  }
  function sprite(id,x,y){return `<div class="hero-floor-character" style="left:${x}%;top:${y}%;right:auto;bottom:auto"><div class="animated-avatar" style="background-image:url('${base}characters/${id}/idle-sheet.png')" role="img" aria-label="${id} animated idle character"></div></div>`;}
  function drawRoom(id){const f=friends[id];const img=layered?`rooms/${id}/${id}-empty.svg`:f.image;
    const hotspotsHTML=hotspots[id].map((h,i)=>`<button class="room-hotspot" style="left:${h.x}%;top:${h.y}%;transform:translate(-50%,-50%);animation-delay:${i*70}ms" data-object="${h.id}" data-label="${h.label}" aria-label="${h.label}">${h.icon}${h.id==='letter'&&Array.isArray(saved.letters[id])&&saved.letters[id].length?'<span class="new"></span>':''}</button>`).join('');
    scene.innerHTML=`<div class="room-scene ${layered?'room-layered':''}" data-room="${id}"><div class="room-backdrop"></div><div class="room-scene-bg"><img src="${base}${img}" alt="Illustrated ${f.name} room"></div>${layered?layerProps(id):''}<div class="room-caption"><span class="eyebrow">${id==='lounge'?'THE SHARED SPACE':f.caption.toUpperCase()}</span><h2>${f.name}</h2><p>${f.desc}</p></div>${layered?'<span class="layered-scene-label">✳ Separate editable prop layers</span>':''}${hotspotsHTML}${id==='lounge'?loungeExtras():sprite(f.character,76,74)}</div>`;
  }
  function loungeExtras(){const duo=join.has('maya'),trio=join.has('leo');const chosen=trio?'Our accidental road trip':duo?'The film we both love':'Your shared little corner';const detail=trio?'The three of you never agreed on the playlist.':duo?'Maya loves Before Sunrise too.':'Invite a friend to discover what connects you.';
    return `<section class="lounge-presence"><p class="tiny-heading">WHO'S HERE? <span style="font-size:12px">✳</span></p><div class="presence-people"><button class="person-btn" aria-pressed="true" disabled>You ✓</button><button class="person-btn" aria-pressed="${duo}" data-member="maya">Maya ${duo?'✓':'+'}</button><button class="person-btn" aria-pressed="${trio}" data-member="leo">Leo ${trio?'✓':'+'}</button></div><p class="mini-help">Try changing who's visiting. The room will reveal different shared stories.</p></section><div class="dynamic-memory" role="note"><img src="${base}props/${trio?'photo-frames':duo?'posters':'letter-envelope'}.svg" alt=""><strong>${escapeHTML(chosen)}</strong><small>${escapeHTML(detail)}</small></div>${trio?`<div class="lounge-sprite"><div class="animated-avatar" style="background-image:url('${base}characters/leo/idle-sheet.png')" role="img" aria-label="Leo is visiting"></div></div>`:''}`;}
  function entriesSheet(type,person){const list=entries[person]?.[type]||[];const name=friends[person].name;const heading={books:'The bookshelf',movie:'The movie wall',gallery:'The gallery'}[type];const portrait={books:'bookcase',movie:'posters',gallery:'gallery-wall'}[type];showSheet(`${name.toUpperCase()} / ${heading.toUpperCase()}`,`<h2>${heading}</h2><p>A few things ${name} chose to share with close friends. The stories are in the details, not the number of likes.</p><div class="object-entry"><img src="${base}props/${portrait}.svg" alt=""><div><h3>${name}'s little collection</h3><p>Curated, not an endless feed.</p></div></div>${list.map(item=>`<div class="object-entry"><img src="${base}props/${item.image}" alt=""><div><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.detail)}</p></div></div>`).join('')}<button class="sheet-btn" data-action="letter" data-recipient="${person}">✉ Leave ${name} a little letter ↗</button>`);}
  function letterSheet(recipient){const person=friends[recipient];const savedNotes=Array.isArray(saved.letters[recipient])?saved.letters[recipient]:[];showSheet('A LITTLE LETTER',`<h2>Leave something<br>for ${person.name}.</h2><p>A note tucked into a room feels different from another notification.</p>${savedNotes.length?`<div class="letter-paper"><small class="letter-badge">✉ SAVED IN THIS BROWSER</small><p>${escapeHTML(savedNotes[savedNotes.length-1])}</p></div>`:''}<label for="note-input" class="eyebrow">YOUR NOTE</label><textarea id="note-input" class="letter-input" maxlength="300" placeholder="Hey, I saw this and thought of you…"></textarea><button class="sheet-btn" data-action="seal-letter" data-recipient="${recipient}">Seal the letter ↗</button><span class="sheet-note">Demo only: the note is saved on this device. It isn't delivered to another person.</span>`);}
  function loungeMemory(){const trio=join.has('leo'),duo=join.has('maya');showSheet('THE STORIES BETWEEN US',`<h2>What the room remembers.</h2><p>When different friends gather, the lounge draws from the moments and favorites they have actually shared.</p><div class="object-entry"><img src="${base}props/photo-frames.svg" alt=""><div><h3>${trio?'That summer road trip':duo?'A film you both love':'Our photo corner'}</h3><p>${trio?'The three of you forgot the directions and found a little seaside café.':duo?'Before Sunrise showed up on both your movie walls.':'Collect a small shared moment to give the room something to remember.'}</p></div></div><div class="object-entry"><img src="${base}props/letter-stack.svg" alt=""><div><h3>It grows through real moments</h3><p>Nothing is invented. Friends choose what memories to bring into the space.</p></div></div><button class="sheet-btn" data-action="keep-memory">♥ Keep this story</button>`);}
  function tvSheet(){showSheet('THE TV CABINET',`<h2>Something to watch<br>together?</h2><p>The lounge pulls from films you've saved and recommendations friends have left on their walls.</p><div class="object-entry"><img src="${base}props/posters.svg" alt=""><div><h3>Before Sunrise</h3><p>You and Maya both have this on your walls.</p></div></div><button class="sheet-btn" data-action="watch">▸ Put it on our watch list</button><span class="sheet-note">This creates a local demo suggestion, not a real shared invitation.</span>`);}
  function memoryBox(){const count=(saved.letters.maya||[]).length+(saved.letters.leo||[]).length;showSheet('THE LETTER TRAY',`<h2>Little things, left<br>for each other.</h2><p>Letters are private to their sender and recipient. This demo shows only letters saved in your own browser.</p><div class="object-entry"><img src="${base}props/letter-stack.svg" alt=""><div><h3>${count?`${count} local demo note${count===1?'':'s'}`:'The letter tray is waiting'}</h3><p>Find a story in your friend's room, then leave them something personal.</p></div></div><button class="sheet-btn" data-action="goto-maya">Visit Maya's letter desk ↗</button>`);}
  function handleObject(object){if(view==='house')return;clickSound();if(object==='books')entriesSheet('books',view);else if(object==='movie')entriesSheet('movie',view);else if(object==='gallery')entriesSheet('gallery',view);else if(object==='letter')letterSheet(view);else if(object==='music')showSheet('THE RECORD PLAYER',`<h2>Leo's current rotation.</h2><p>Some songs feel like people. Leo keeps the ones that remind him of particular friends.</p><div class="object-entry"><img src="${base}props/record-disc.svg" alt=""><div><h3>Late night, early train</h3><p>“This always makes me think of the ride home.”</p></div></div><button class="sheet-btn" data-action="letter" data-recipient="leo">✉ Tell Leo what this reminds you of</button>`);else if(object==='memory')loungeMemory();else if(object==='tv')tvSheet();else if(object==='letters')memoryBox();else if(object==='table')showSheet('THE COFFEE TABLE',`<h2>Where stories<br>get passed around.</h2><p>The coffee table holds small moments friends chose to share with the group.</p><div class="object-entry"><img src="${base}props/photo-single.svg" alt=""><div><h3>Friday at the café</h3><p>“The one where we stayed until closing.”</p></div></div><button class="sheet-btn" data-action="keep-memory">♥ Save this little moment</button>`);}
  function moveCharacter(x,y){
    if(view==='house')return;
    const character=scene.querySelector('.hero-floor-character');
    const avatar=character?.querySelector('.animated-avatar');
    if(!character||!avatar)return;
    const oldX=parseFloat(character.style.left||'76');
    const nextX=Math.max(25,Math.min(80,x));
    const nextY=Math.max(70,Math.min(79,y));
    const id=friends[view].character;
    clearTimeout(walkTimer);
    avatar.style.backgroundImage=`url('${base}characters/${id}/walk-sheet.png')`;
    avatar.classList.add('moving');
    avatar.style.transform=nextX<oldX?'scaleX(-1)':'scaleX(1)';
    const duration=Math.max(300,Math.min(1200,Math.hypot(nextX-oldX,nextY-74)*22));
    character.style.transition=`left ${duration}ms linear, top ${duration}ms linear`;
    character.style.left=nextX+'%';character.style.top=nextY+'%';
    walkTimer=setTimeout(()=>{avatar.classList.remove('moving');avatar.style.backgroundImage=`url('${base}characters/${id}/idle-sheet.png')`;},duration);
  }
  scene.addEventListener('click',event=>{
    const target=event.target.closest('[data-room],[data-object],[data-member]');
    if(target){if(target.dataset.room){enter(target.dataset.room);return;}if(target.dataset.object){handleObject(target.dataset.object);return;}if(target.dataset.member){const id=target.dataset.member;if(join.has(id))join.delete(id);else join.add(id);clickSound();drawRoom('lounge');showToast(`${friends[id].name} ${join.has(id)?'joined':'left'} the lounge`);return;}}
    // The clickable ground strip is intentionally constrained; no claim of obstacle pathfinding.
    if(view==='house'||!event.target.closest('.room-scene-bg, .room-backdrop, .room-scene'))return;
    const room=scene.querySelector('.room-scene');if(!room)return;
    const bounds=room.getBoundingClientRect();
    const x=((event.clientX-bounds.left)/bounds.width)*100;
    const y=((event.clientY-bounds.top)/bounds.height)*100;
    if(y>56)moveCharacter(x,y);
  });
  body.addEventListener('click',event=>{const button=event.target.closest('[data-action]');if(!button)return;const action=button.dataset.action;if(action==='letter'){letterSheet(button.dataset.recipient);return;}if(action==='seal-letter'){const to=button.dataset.recipient,v=document.getElementById('note-input')?.value.trim();if(!v){showToast('Write a note before sealing it ✉');return;}if(!Array.isArray(saved.letters[to]))saved.letters[to]=[];saved.letters[to].push(v);save();clickSound();showSheet('LETTER SEALED',`<h2>A little note,<br>left with love.</h2><div class="letter-paper"><span class="letter-badge">SEALED WITH ♥</span><p>${escapeHTML(v)}</p></div><p>Your note is saved in this browser's demo state. It wasn't sent to ${friends[to].name}.</p><button class="sheet-btn" data-action="close">Return to the room ↗</button>`);return;}if(action==='watch'){saved.watch=Array.isArray(saved.watch)?saved.watch:[];if(!saved.watch.includes('Before Sunrise'))saved.watch.push('Before Sunrise');save();closeSheet();showToast('Saved to the demo group watch list ✓');return;}if(action==='keep-memory'){closeSheet();showToast('A little story worth remembering ♥');return;}if(action==='goto-maya'){closeSheet();enter('maya');return;}if(action==='close'){closeSheet();return;}});
  document.getElementById('close-sheet').addEventListener('click',closeSheet);
  scrim.addEventListener('click',closeSheet);
  back.addEventListener('click',goHome);
  artToggle.addEventListener('click',()=>{layered=!layered;artToggle.setAttribute('aria-pressed',String(layered));artToggle.textContent=layered?'◆ Illustration view':'◇ Layer view';clickSound();if(view!=='house')drawRoom(view);showToast(layered?'Layered asset view: independent prop sprites':'Illustrated concept view');});
  soundToggle.addEventListener('click',()=>{sound=!sound;soundToggle.textContent=sound?'♫ Sound on':'♪ Sound off';soundToggle.setAttribute('aria-pressed',String(sound));clickSound();});
  document.getElementById('help-btn').addEventListener('click',()=>showSheet('HOW TO EXPLORE',`<h2>A little place<br>for your people.</h2><p>Click a room in the house overview. When you're inside, the small circles mark the objects you can explore.</p><div class="object-entry"><img src="${base}props/bookcase.svg" alt=""><div><h3>Personal rooms</h3><p>Visit book walls, posters and photos. Leave a letter that is stored locally for this demo.</p></div></div><div class="object-entry"><img src="${base}props/sofa.svg" alt=""><div><h3>Shared lounge</h3><p>Invite Maya or Leo using the chips. Shared memory objects will change to reflect who's there.</p></div></div><p><strong>Keyboard:</strong> Esc closes a story or returns to the house. Press H from any room to return home. Tab reaches every interactive hotspot.</p><button class="sheet-btn" data-action="close">Got it ↗</button>`));
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){if(!sheet.hidden){closeSheet();event.preventDefault();return;}if(view!=='house'){goHome();event.preventDefault();}}if(event.key.toLowerCase()==='h'&&view!=='house'&&sheet.hidden&&!['TEXTAREA','INPUT'].includes(document.activeElement?.tagName)){goHome();}});
  draw();
})();
